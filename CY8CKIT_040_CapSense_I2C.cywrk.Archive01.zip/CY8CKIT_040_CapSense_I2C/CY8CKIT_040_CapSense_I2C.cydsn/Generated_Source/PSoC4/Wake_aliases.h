/*******************************************************************************
* File Name: Wake.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Wake_ALIASES_H) /* Pins Wake_ALIASES_H */
#define CY_PINS_Wake_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Wake_0			(Wake__0__PC)
#define Wake_0_PS		(Wake__0__PS)
#define Wake_0_PC		(Wake__0__PC)
#define Wake_0_DR		(Wake__0__DR)
#define Wake_0_SHIFT	(Wake__0__SHIFT)
#define Wake_0_INTR	((uint16)((uint16)0x0003u << (Wake__0__SHIFT*2u)))

#define Wake_INTR_ALL	 ((uint16)(Wake_0_INTR))


#endif /* End Pins Wake_ALIASES_H */


/* [] END OF FILE */
