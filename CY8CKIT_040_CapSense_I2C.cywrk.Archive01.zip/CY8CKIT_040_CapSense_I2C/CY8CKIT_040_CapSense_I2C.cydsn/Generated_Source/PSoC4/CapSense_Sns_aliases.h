/*******************************************************************************
* File Name: CapSense_Sns.h  
* Version 2.10
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CapSense_Sns_ALIASES_H) /* Pins CapSense_Sns_ALIASES_H */
#define CY_PINS_CapSense_Sns_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define CapSense_Sns_0		(CapSense_Sns__0__PC)
#define CapSense_Sns_0_PS		(CapSense_Sns__0__PS)
#define CapSense_Sns_0_PC		(CapSense_Sns__0__PC)
#define CapSense_Sns_0_DR		(CapSense_Sns__0__DR)
#define CapSense_Sns_0_SHIFT	(CapSense_Sns__0__SHIFT)

#define CapSense_Sns_1		(CapSense_Sns__1__PC)
#define CapSense_Sns_1_PS		(CapSense_Sns__1__PS)
#define CapSense_Sns_1_PC		(CapSense_Sns__1__PC)
#define CapSense_Sns_1_DR		(CapSense_Sns__1__DR)
#define CapSense_Sns_1_SHIFT	(CapSense_Sns__1__SHIFT)

#define CapSense_Sns_2		(CapSense_Sns__2__PC)
#define CapSense_Sns_2_PS		(CapSense_Sns__2__PS)
#define CapSense_Sns_2_PC		(CapSense_Sns__2__PC)
#define CapSense_Sns_2_DR		(CapSense_Sns__2__DR)
#define CapSense_Sns_2_SHIFT	(CapSense_Sns__2__SHIFT)

#define CapSense_Sns_3		(CapSense_Sns__3__PC)
#define CapSense_Sns_3_PS		(CapSense_Sns__3__PS)
#define CapSense_Sns_3_PC		(CapSense_Sns__3__PC)
#define CapSense_Sns_3_DR		(CapSense_Sns__3__DR)
#define CapSense_Sns_3_SHIFT	(CapSense_Sns__3__SHIFT)

#define CapSense_Sns_4		(CapSense_Sns__4__PC)
#define CapSense_Sns_4_PS		(CapSense_Sns__4__PS)
#define CapSense_Sns_4_PC		(CapSense_Sns__4__PC)
#define CapSense_Sns_4_DR		(CapSense_Sns__4__DR)
#define CapSense_Sns_4_SHIFT	(CapSense_Sns__4__SHIFT)

#define CapSense_Sns_5		(CapSense_Sns__5__PC)
#define CapSense_Sns_5_PS		(CapSense_Sns__5__PS)
#define CapSense_Sns_5_PC		(CapSense_Sns__5__PC)
#define CapSense_Sns_5_DR		(CapSense_Sns__5__DR)
#define CapSense_Sns_5_SHIFT	(CapSense_Sns__5__SHIFT)

#define CapSense_Sns_6		(CapSense_Sns__6__PC)
#define CapSense_Sns_6_PS		(CapSense_Sns__6__PS)
#define CapSense_Sns_6_PC		(CapSense_Sns__6__PC)
#define CapSense_Sns_6_DR		(CapSense_Sns__6__DR)
#define CapSense_Sns_6_SHIFT	(CapSense_Sns__6__SHIFT)

#define CapSense_Sns_7		(CapSense_Sns__7__PC)
#define CapSense_Sns_7_PS		(CapSense_Sns__7__PS)
#define CapSense_Sns_7_PC		(CapSense_Sns__7__PC)
#define CapSense_Sns_7_DR		(CapSense_Sns__7__DR)
#define CapSense_Sns_7_SHIFT	(CapSense_Sns__7__SHIFT)

#define CapSense_Sns_8		(CapSense_Sns__8__PC)
#define CapSense_Sns_8_PS		(CapSense_Sns__8__PS)
#define CapSense_Sns_8_PC		(CapSense_Sns__8__PC)
#define CapSense_Sns_8_DR		(CapSense_Sns__8__DR)
#define CapSense_Sns_8_SHIFT	(CapSense_Sns__8__SHIFT)

#define CapSense_Sns_9		(CapSense_Sns__9__PC)
#define CapSense_Sns_9_PS		(CapSense_Sns__9__PS)
#define CapSense_Sns_9_PC		(CapSense_Sns__9__PC)
#define CapSense_Sns_9_DR		(CapSense_Sns__9__DR)
#define CapSense_Sns_9_SHIFT	(CapSense_Sns__9__SHIFT)

#define CapSense_Sns_10		(CapSense_Sns__10__PC)
#define CapSense_Sns_10_PS		(CapSense_Sns__10__PS)
#define CapSense_Sns_10_PC		(CapSense_Sns__10__PC)
#define CapSense_Sns_10_DR		(CapSense_Sns__10__DR)
#define CapSense_Sns_10_SHIFT	(CapSense_Sns__10__SHIFT)


#define CapSense_Sns_Touchpad0_Col0__TP		(CapSense_Sns__Touchpad0_Col0__TP__PC)
#define CapSense_Sns_Touchpad0_Col0__TP_PS		(CapSense_Sns__Touchpad0_Col0__TP__PS)
#define CapSense_Sns_Touchpad0_Col0__TP_PC		(CapSense_Sns__Touchpad0_Col0__TP__PC)
#define CapSense_Sns_Touchpad0_Col0__TP_DR		(CapSense_Sns__Touchpad0_Col0__TP__DR)
#define CapSense_Sns_Touchpad0_Col0__TP_SHIFT	(CapSense_Sns__Touchpad0_Col0__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Col1__TP		(CapSense_Sns__Touchpad0_Col1__TP__PC)
#define CapSense_Sns_Touchpad0_Col1__TP_PS		(CapSense_Sns__Touchpad0_Col1__TP__PS)
#define CapSense_Sns_Touchpad0_Col1__TP_PC		(CapSense_Sns__Touchpad0_Col1__TP__PC)
#define CapSense_Sns_Touchpad0_Col1__TP_DR		(CapSense_Sns__Touchpad0_Col1__TP__DR)
#define CapSense_Sns_Touchpad0_Col1__TP_SHIFT	(CapSense_Sns__Touchpad0_Col1__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Col2__TP		(CapSense_Sns__Touchpad0_Col2__TP__PC)
#define CapSense_Sns_Touchpad0_Col2__TP_PS		(CapSense_Sns__Touchpad0_Col2__TP__PS)
#define CapSense_Sns_Touchpad0_Col2__TP_PC		(CapSense_Sns__Touchpad0_Col2__TP__PC)
#define CapSense_Sns_Touchpad0_Col2__TP_DR		(CapSense_Sns__Touchpad0_Col2__TP__DR)
#define CapSense_Sns_Touchpad0_Col2__TP_SHIFT	(CapSense_Sns__Touchpad0_Col2__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Col3__TP		(CapSense_Sns__Touchpad0_Col3__TP__PC)
#define CapSense_Sns_Touchpad0_Col3__TP_PS		(CapSense_Sns__Touchpad0_Col3__TP__PS)
#define CapSense_Sns_Touchpad0_Col3__TP_PC		(CapSense_Sns__Touchpad0_Col3__TP__PC)
#define CapSense_Sns_Touchpad0_Col3__TP_DR		(CapSense_Sns__Touchpad0_Col3__TP__DR)
#define CapSense_Sns_Touchpad0_Col3__TP_SHIFT	(CapSense_Sns__Touchpad0_Col3__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Col4__TP		(CapSense_Sns__Touchpad0_Col4__TP__PC)
#define CapSense_Sns_Touchpad0_Col4__TP_PS		(CapSense_Sns__Touchpad0_Col4__TP__PS)
#define CapSense_Sns_Touchpad0_Col4__TP_PC		(CapSense_Sns__Touchpad0_Col4__TP__PC)
#define CapSense_Sns_Touchpad0_Col4__TP_DR		(CapSense_Sns__Touchpad0_Col4__TP__DR)
#define CapSense_Sns_Touchpad0_Col4__TP_SHIFT	(CapSense_Sns__Touchpad0_Col4__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Col5__TP		(CapSense_Sns__Touchpad0_Col5__TP__PC)
#define CapSense_Sns_Touchpad0_Col5__TP_PS		(CapSense_Sns__Touchpad0_Col5__TP__PS)
#define CapSense_Sns_Touchpad0_Col5__TP_PC		(CapSense_Sns__Touchpad0_Col5__TP__PC)
#define CapSense_Sns_Touchpad0_Col5__TP_DR		(CapSense_Sns__Touchpad0_Col5__TP__DR)
#define CapSense_Sns_Touchpad0_Col5__TP_SHIFT	(CapSense_Sns__Touchpad0_Col5__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Row0__TP		(CapSense_Sns__Touchpad0_Row0__TP__PC)
#define CapSense_Sns_Touchpad0_Row0__TP_PS		(CapSense_Sns__Touchpad0_Row0__TP__PS)
#define CapSense_Sns_Touchpad0_Row0__TP_PC		(CapSense_Sns__Touchpad0_Row0__TP__PC)
#define CapSense_Sns_Touchpad0_Row0__TP_DR		(CapSense_Sns__Touchpad0_Row0__TP__DR)
#define CapSense_Sns_Touchpad0_Row0__TP_SHIFT	(CapSense_Sns__Touchpad0_Row0__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Row1__TP		(CapSense_Sns__Touchpad0_Row1__TP__PC)
#define CapSense_Sns_Touchpad0_Row1__TP_PS		(CapSense_Sns__Touchpad0_Row1__TP__PS)
#define CapSense_Sns_Touchpad0_Row1__TP_PC		(CapSense_Sns__Touchpad0_Row1__TP__PC)
#define CapSense_Sns_Touchpad0_Row1__TP_DR		(CapSense_Sns__Touchpad0_Row1__TP__DR)
#define CapSense_Sns_Touchpad0_Row1__TP_SHIFT	(CapSense_Sns__Touchpad0_Row1__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Row2__TP		(CapSense_Sns__Touchpad0_Row2__TP__PC)
#define CapSense_Sns_Touchpad0_Row2__TP_PS		(CapSense_Sns__Touchpad0_Row2__TP__PS)
#define CapSense_Sns_Touchpad0_Row2__TP_PC		(CapSense_Sns__Touchpad0_Row2__TP__PC)
#define CapSense_Sns_Touchpad0_Row2__TP_DR		(CapSense_Sns__Touchpad0_Row2__TP__DR)
#define CapSense_Sns_Touchpad0_Row2__TP_SHIFT	(CapSense_Sns__Touchpad0_Row2__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Row3__TP		(CapSense_Sns__Touchpad0_Row3__TP__PC)
#define CapSense_Sns_Touchpad0_Row3__TP_PS		(CapSense_Sns__Touchpad0_Row3__TP__PS)
#define CapSense_Sns_Touchpad0_Row3__TP_PC		(CapSense_Sns__Touchpad0_Row3__TP__PC)
#define CapSense_Sns_Touchpad0_Row3__TP_DR		(CapSense_Sns__Touchpad0_Row3__TP__DR)
#define CapSense_Sns_Touchpad0_Row3__TP_SHIFT	(CapSense_Sns__Touchpad0_Row3__TP__SHIFT)

#define CapSense_Sns_Touchpad0_Row4__TP		(CapSense_Sns__Touchpad0_Row4__TP__PC)
#define CapSense_Sns_Touchpad0_Row4__TP_PS		(CapSense_Sns__Touchpad0_Row4__TP__PS)
#define CapSense_Sns_Touchpad0_Row4__TP_PC		(CapSense_Sns__Touchpad0_Row4__TP__PC)
#define CapSense_Sns_Touchpad0_Row4__TP_DR		(CapSense_Sns__Touchpad0_Row4__TP__DR)
#define CapSense_Sns_Touchpad0_Row4__TP_SHIFT	(CapSense_Sns__Touchpad0_Row4__TP__SHIFT)


#endif /* End Pins CapSense_Sns_ALIASES_H */


/* [] END OF FILE */
