/*******************************************************************************
* File Name: WakeISR.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_WakeISR_H)
#define CY_ISR_WakeISR_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void WakeISR_Start(void);
void WakeISR_StartEx(cyisraddress address);
void WakeISR_Stop(void);

CY_ISR_PROTO(WakeISR_Interrupt);

void WakeISR_SetVector(cyisraddress address);
cyisraddress WakeISR_GetVector(void);

void WakeISR_SetPriority(uint8 priority);
uint8 WakeISR_GetPriority(void);

void WakeISR_Enable(void);
uint8 WakeISR_GetState(void);
void WakeISR_Disable(void);

void WakeISR_SetPending(void);
void WakeISR_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the WakeISR ISR. */
#define WakeISR_INTC_VECTOR            ((reg32 *) WakeISR__INTC_VECT)

/* Address of the WakeISR ISR priority. */
#define WakeISR_INTC_PRIOR             ((reg32 *) WakeISR__INTC_PRIOR_REG)

/* Priority of the WakeISR interrupt. */
#define WakeISR_INTC_PRIOR_NUMBER      WakeISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable WakeISR interrupt. */
#define WakeISR_INTC_SET_EN            ((reg32 *) WakeISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the WakeISR interrupt. */
#define WakeISR_INTC_CLR_EN            ((reg32 *) WakeISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the WakeISR interrupt state to pending. */
#define WakeISR_INTC_SET_PD            ((reg32 *) WakeISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the WakeISR interrupt. */
#define WakeISR_INTC_CLR_PD            ((reg32 *) WakeISR__INTC_CLR_PD_REG)



#endif /* CY_ISR_WakeISR_H */


/* [] END OF FILE */
