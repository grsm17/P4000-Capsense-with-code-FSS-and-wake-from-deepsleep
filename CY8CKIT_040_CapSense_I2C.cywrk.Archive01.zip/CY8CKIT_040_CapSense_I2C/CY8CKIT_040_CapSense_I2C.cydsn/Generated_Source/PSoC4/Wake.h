/*******************************************************************************
* File Name: Wake.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Wake_H) /* Pins Wake_H */
#define CY_PINS_Wake_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Wake_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} Wake_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   Wake_Read(void);
void    Wake_Write(uint8 value);
uint8   Wake_ReadDataReg(void);
#if defined(Wake__PC) || (CY_PSOC4_4200L) 
    void    Wake_SetDriveMode(uint8 mode);
#endif
void    Wake_SetInterruptMode(uint16 position, uint16 mode);
uint8   Wake_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void Wake_Sleep(void); 
void Wake_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(Wake__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define Wake_DRIVE_MODE_BITS        (3)
    #define Wake_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Wake_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the Wake_SetDriveMode() function.
         *  @{
         */
        #define Wake_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define Wake_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define Wake_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define Wake_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define Wake_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define Wake_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define Wake_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define Wake_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define Wake_MASK               Wake__MASK
#define Wake_SHIFT              Wake__SHIFT
#define Wake_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Wake_SetInterruptMode() function.
     *  @{
     */
        #define Wake_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define Wake_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define Wake_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define Wake_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(Wake__SIO)
    #define Wake_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(Wake__PC) && (CY_PSOC4_4200L)
    #define Wake_USBIO_ENABLE               ((uint32)0x80000000u)
    #define Wake_USBIO_DISABLE              ((uint32)(~Wake_USBIO_ENABLE))
    #define Wake_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define Wake_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define Wake_USBIO_ENTER_SLEEP          ((uint32)((1u << Wake_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << Wake_USBIO_SUSPEND_DEL_SHIFT)))
    #define Wake_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << Wake_USBIO_SUSPEND_SHIFT)))
    #define Wake_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << Wake_USBIO_SUSPEND_DEL_SHIFT)))
    #define Wake_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(Wake__PC)
    /* Port Configuration */
    #define Wake_PC                 (* (reg32 *) Wake__PC)
#endif
/* Pin State */
#define Wake_PS                     (* (reg32 *) Wake__PS)
/* Data Register */
#define Wake_DR                     (* (reg32 *) Wake__DR)
/* Input Buffer Disable Override */
#define Wake_INP_DIS                (* (reg32 *) Wake__PC2)

/* Interrupt configuration Registers */
#define Wake_INTCFG                 (* (reg32 *) Wake__INTCFG)
#define Wake_INTSTAT                (* (reg32 *) Wake__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define Wake_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(Wake__SIO)
    #define Wake_SIO_REG            (* (reg32 *) Wake__SIO)
#endif /* (Wake__SIO_CFG) */

/* USBIO registers */
#if !defined(Wake__PC) && (CY_PSOC4_4200L)
    #define Wake_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define Wake_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define Wake_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define Wake_DRIVE_MODE_SHIFT       (0x00u)
#define Wake_DRIVE_MODE_MASK        (0x07u << Wake_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins Wake_H */


/* [] END OF FILE */
