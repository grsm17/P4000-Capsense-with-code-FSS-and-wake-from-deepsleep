/******************************************************************************
* Project Name		: CY8CKIT_040_CapSense_I2C
* File Name			: main.c
* Version 			: 1.0
* Device Used		: CY8C4014LQI-422
* Software Used		: PSoC Creator 3.2 SP1
* Compiler    		: ARM GCC 4.8.4, ARM MDK Generic
* Related Hardware	: CY8CKIT-040 PSoC 4000 Pioneer Kit 
*
********************************************************************************
* Copyright (2015), Cypress Semiconductor Corporation. All Rights Reserved.
********************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress)
* and is protected by and subject to worldwide patent protection (United
* States and foreign), United States copyright laws and international treaty
* provisions. Cypress hereby grants to licensee a personal, non-exclusive,
* non-transferable license to copy, use, modify, create derivative works of,
* and compile the Cypress Source Code and derivative works for the sole
* purpose of creating custom software in support of licensee product to be
* used only in conjunction with a Cypress integrated circuit as specified in
* the applicable agreement. Any reproduction, modification, translation,
* compilation, or representation of this software except as specified above 
* is prohibited without the express written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH 
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the 
* materials described herein. Cypress does not assume any liability arising out 
* of the application or use of any product or circuit described herein. Cypress 
* does not authorize its products for use as critical components in life-support 
* systems where a malfunction or failure may reasonably be expected to result in 
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of 
* such use and in doing so indemnifies Cypress against all charges. 
*
* Use of this Software may be limited by and subject to the applicable Cypress
* software license agreement. 
*******************************************************************************/

/******************************************************************************
*                           THEORY OF OPERATION
* The project demonstrates CapSense trackpad with I2C tuner for data viewing.
*	Though I2C tuner can be used to tune the trackpad in manual tuning mode,
*	SmartSense is used in the project to implement the trackpad. Hence data
*	can only be viewed in Tuner GUI for SNR & trackpad position.
*
* Hardware connection required for testing -* 
* Trackpad 	- Refer CYDWR file for details (requires Trackpad shield connection)
* Cmod pin	- P0[4] (connected in the board itself)
* I2C pins	- P1[2]/P1[3] (SCL/SDA lines - hard-wired in the board) 
******************************************************************************/
#include <project.h>
#define SENSOR1 1
#define SENSOR2 2
#define SENSOR3 3
#define SENSOR4 4
#define NONE 0
uint8 STATE = NONE;


#define DEEPSLEEP //uncomment to enable deep sleep and wake up from button press
#define TUNER //uncomment to enable tuner for test and debug purposes.

CY_ISR_PROTO(DeepSleepWakeUpHandler);
/******************************************************************************
* Function Name: main
*******************************************************************************
*
* Summary:
*  main() performs following functions:
*  1: Initialize CapSense along with tuner APIs
*  2: Scans the sensors, updates baseline & sends data over I2C tuner comm
*  3: sets the state depending on which buttons are pressed, only allowing a change when a single button is pressed
*  4: Optional deep sleep function which is enabled by #define DEEPSLEEP. wake from deep sleep by rising edge on wake pin
*
* Parameters:
*  None.
*
* Return:
*  None.
*
******************************************************************************/
int main()
{
    
    CyGlobalIntEnable; /* Enable global interrupts */
    
    #ifdef DEEPSLEEP
    uint32 deepsleepcount=0;
    WakeISR_StartEx(DeepSleepWakeUpHandler);
    #endif
    
    #ifdef TUNER
    EZI2C_Start(); /* Start EZI2C component */
    /*
    * Set up communication and initialize data buffer to CapSense data structure
    * to use Tuner application
    */
    EZI2C_EzI2CSetBuffer1(sizeof(CapSense_dsRam), sizeof(CapSense_dsRam),
    (uint8 *)&CapSense_dsRam);
    #endif
    
    CapSense_Start(); /* Initialize component */

    CapSense_ScanAllWidgets(); /* Scan all widgets */
    
    RED_Write(1);//turn all leds off
    GREEN_Write(1);
    BLUE_Write(1);

    for(;;)
    {
        /* Do this only when a scan is done */
        if(CapSense_NOT_BUSY == CapSense_IsBusy())
        {
        
            CapSense_ProcessAllWidgets(); /* Process all widgets */
        
            #ifdef TUNER
            CapSense_RunTuner(); /* To sync with Tuner application */
            #endif
        
            if (CapSense_IsAnyWidgetActive()) /* Scan result verification */
            {
                #ifdef DEEPSLEEP
                deepsleepcount=0;
                #endif
            
                if(((CapSense_IsWidgetActive(0)))&& (!(CapSense_IsWidgetActive(1)))&& (!(CapSense_IsWidgetActive(2))) && (!(CapSense_IsWidgetActive(3))))
                {
                    STATE= SENSOR1;
                }
                else if((!(CapSense_IsWidgetActive(0)))&& ((CapSense_IsWidgetActive(1)))&& (!(CapSense_IsWidgetActive(2))) && (!(CapSense_IsWidgetActive(3))))
                {
                    STATE=SENSOR2;
                }
                else if((!(CapSense_IsWidgetActive(0)))&& (!(CapSense_IsWidgetActive(1)))&& ((CapSense_IsWidgetActive(2))) && (!(CapSense_IsWidgetActive(3))))
                {
                    STATE=SENSOR3;
                }
                else if((!(CapSense_IsWidgetActive(0)))&& (!(CapSense_IsWidgetActive(1)))&& (!(CapSense_IsWidgetActive(2))) && ((CapSense_IsWidgetActive(3))))
                {
                    STATE=SENSOR4;                
                }
            }
            else
            {
                    STATE=NONE;
            }
            CapSense_ScanAllWidgets(); /* Start next scan */
        }
        
        switch(STATE)
        {
        case NONE:
            RED_Write(1);
            BLUE_Write(1);
            GREEN_Write(1);
            break;
            
        case SENSOR1:
            RED_Write(0);
            BLUE_Write(1);
            GREEN_Write(1);
            break;
            
        case SENSOR2:
            RED_Write(1);
            BLUE_Write(0);
            GREEN_Write(1);
            break;
            
        case SENSOR3:
            RED_Write(1);
            BLUE_Write(1);
            GREEN_Write(0);
            break; 
            
        case SENSOR4:
            RED_Write(0);
            BLUE_Write(0);
            GREEN_Write(0);
            break; 
            
        default:
            STATE = NONE;
            break;
        }
         
        #ifdef DEEPSLEEP
        deepsleepcount++;
        if(deepsleepcount==1000000)
        {
            deepsleepcount=0;
            BLUE_Write(0);
            CyDelay(1000);
            RED_Write(0);
            BLUE_Write(1);
            CyDelay(1000);
            GREEN_Write(0);
            RED_Write(1);
            CyDelay(1000);
            GREEN_Write(1);
            CapSense_Sleep();
            EZI2C_Sleep();
            CySysPmDeepSleep();
            EZI2C_Wakeup();
            CapSense_Wakeup();
        }
        #endif
    }
}
    
CY_ISR(DeepSleepWakeUpHandler)
{
    WakeISR_ClearPending();
    Wake_ClearInterrupt();
    RED_Write(0);
    GREEN_Write(0);
    CyDelay(2000);
    RED_Write(1);
    GREEN_Write(1); 
    
}
/* [] END OF FILE */
